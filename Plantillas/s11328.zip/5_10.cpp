/*
Nombre completo:
DNI:
Usuario del juez:
Puesto de laboratorio:
Qué has conseguido hacer y qué no:
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include "queue_eda.h"
#include <vector>
using namespace std;

template <class T>
class queue_plus : public queue<T> {
    using Nodo = typename queue<T>::Nodo;

public:
    void replicaElems(vector<int> const& mult) {
        
        Nodo* ite = this->prim;
        Nodo* pre_ite = ite;
        Nodo* aux = nullptr;


        for (int m : mult) {

            if (m == 0) {

                if (ite != this->prim) {
                    aux = ite->sig;

                    pre_ite->sig = aux;
                    ite = aux;
                    this->nelems--;
                }
                else {
                    pre_ite = ite;
                    ite = ite->sig;
                    this->pop();
                }
            }
            else if (m == 1) {
                pre_ite = ite;
                ite = ite->sig;
            }
            else {
                Nodo* d = nullptr;

                for (int i = 0; i < m - 1 ; i++) 
                {
                    aux = ite->sig;

                    if (ite == this->ult) this->push(ite->elem);
                    else {
                        d = new Nodo(ite->elem, ite->sig);  //Duplicamos el nodo

                        ite->sig = d;

                        pre_ite = d;

                        if (m - i > 2) ite = d;
                        else ite = d->sig;
                        

                        if (ite == nullptr) this->ult = ite;
                        this->nelems++;
                    }

                }
            }
        }
    }
};


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    int n;
    queue_plus<int> q;

    cin >> n;
    vector<int> mult(n);
    vector<int> aux(n); // Para darle la vuelta a la secuencia de entrada

    // Leemos la secuencia invertida para q y le damos la vuelta
    for (int i = n - 1; i >= 0; --i) cin >> aux[i];
    for (int e : aux) q.push(e);

    // Leemos la secuencia invertida para mult
    for (int i = n - 1; i >= 0; --i) cin >> mult[i];

    // llamada al metodo
    q.replicaElems(mult);

    // escribir sol (pero antes dar una vuelta para comprobar que la cola está bien formada)
    for (int i = 0; i < q.size(); ++i) {
        n = q.front();
        q.pop();
        q.push(n);
    }

    // Ahora imprimimos la cola y de paso la dejamos vacía (tb para probar su consistencia)
    cout << "[";
    if (!q.empty()) {
        cout << q.front();
        q.pop();
    }
    while (!q.empty()) {
        cout << ", " << q.front();
        q.pop();
    }
    cout << "]" << endl;
    return true;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}
